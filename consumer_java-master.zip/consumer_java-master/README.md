# SFTP Consumer - Projet GOZEN

Ce repository Git contient le Consumer custom développé en Java dans le cadre du projet GOZEN.

Le but du projet est de prendre les données présentes dans un topic Kafka et de les déposer sans
transformation sur un serveur distant au format CSV ou JSON.

## Mode de connexion au Serveur 
La connexion au serveur distant est fait par protocole SSH.
Pour établir la connexion SSH deux modes sont possibles.
- Login / password 
- Clef publique / clef privée (Recommandé)

Pour la configuration de la connexion, voir chapitre sur "Configurations du connecteur"

### Ouverture/fermeture des sessions SSH

Une session SSH est ouverte lorsque qu'il y en a besoin (lazy connection)

En cas d'inactivité ou d'erreur applicative toutes les connections sont fermées

## Format du fichier de sortie

Le fichier en sortie est un fichier CSV ou JSON
Le fichier peut avoir un header (premiere ligne du fichier) et un footer (dernière ligne du fichier)

Pour la configuration du fichier de sortie, voir chapitre sur "Configurations du connecteur"

Implémentation :
Il est possible d'ajouter facilement de nouveaux formats (pattern factory)

## Comportement

Le microservice peut avoir plusieurs comportements décrit ci-dessous.

En cas d'erreur lors de l'execution, le microservice logs les erreur et interrompt son execution.

Implémentation :
Il est possible d'ajouter facilement de nouveaux comportements (pattern strategy + factory)

### Comportement Batch

Le consumer se connecte à Kafka, et vérifie périodiquement la présence de nouveaux messages dans le topic.

Si un nouveau message est présent, la procédure suivante se déroule :
1. Le consumer se connecte au serveur SFTP, et se place dans le dossier distant
2. Un batch de messages de taille configurable va être récupéré depuis le topic
3. Le message est ajouté à la fin du fichier 
4. Une fois les messages inscrit dans le fichier, le nouvel offset est commité, afin de confirmer à Kafka la bonne reception des messages
5. Tant que le topic possède des messages on recommence à l'étape 2
6. Lorsqu'il n'y a plus de messages disponible dans le topic, le microservice attends un certain délai avant d'admettre que la synchronisation est terminée
7. Vérification de l'intégrité des données si celle-ci est paramétrée (voir chapitre sur "Vérification de l'intégrité des données").
8. Lorsque de nouveau messages sont présent dans le topic, l'ancien fichier généré et supprimé et remplacer par un nouveau fichier vierge
9. Retour à l'étape 1 pour lecture et traitement de ces nouveaux messages


### Comportement Temps réel

1. Le consumer se connecte au serveur SFTP, et se place dans le dossier distant
2. Un batch de messages de taille configurable va être récupéré depuis le topic
3. Le message est ajouté à la fin du fichier
4. Une fois les messages inscrit dans le fichier, le nouvel offset est commité, afin de confirmer à Kafka la bonne reception des messages
5. Tant que le topic possède des messages et que le délai de renouvellement du fichier n'est pas atteint, on recommence à l'étape 2
6. Lorsque le délai de renouvellement du fichier est dépassé, on déclenche la vérification de l'intégrité des données si celle-ci est paramétrée
7. Retour à l'étape 1 pour lecture et traitement des nouveaux messages dans un nouveau fichier


## Vérification de l'intégrité des données

Dans le but de vérifier l'intégrité des données, un mécanisme basé sur le nombre de lignes 
présent dans le fichier généré et le nombre de lignes attendu dans le fichier
* Pour le nombre de lignes contenu dans le fichier, on compte le nombre de lignes et on soustrait
les lignes telle que les headers et les footers qui sont ajouté pour des besoins fonctionnelles.
* Pour le nombre de lignes attendu dans le fichier, on récupere cette information dans un topic dédié
ce topic est alimenté en amont lors du début d'une synchronisation de données
  
Si les deux valeurs sont les mêmes alors on peut continuer l'execution du programme normalement
Dans le cas où les deux valeurs sont différentes des logs d'erreurs sont émis

En cas d'erreur lors de la vérification, erreur réseau par exemple, des logs sont émis et
l'execution du microservice s'interrompt



## Configurations

### Configurations du connecteur

Voici la liste des configurations disponibles, ainsi que leurs différentes valeurs. Ceux-ci sont à configurer en variable d'environement du Pod, sous le format suivant :

`paramètre=valeur`

| Paramètre | Obligatoire | Type |  Description | Valeurs possibles | Valeur par défaut | Exemple |
| --------- | ----------- | ---- | ------------ | ----------------- | ----------------- | ------- |
| microservice-strategy | Oui | String | Comportement du microservice, strategies de traitement de la donnée  | `batch`, `realtime` |  | `batch` |
| microservice-enable-data-check | Oui | Booléen | Activation du mécanisme de vérification de l'intégrité des données | `true`, `false` | `false` |  |
| microservice-strategy-batch-delay-before-file-replacement | Oui | Integer | Durée en minute d'inactivité du topic avant lequel un nouveau fichier sera créé (Comportement Batch)| [0, 2147483647[ | 30 |  |
| microservice-strategy-realtime-delay-before-file-replacement | Oui | Integer | Durée en minute avant lequel un nouveau fichier sera créé (Comportement Realtime)| [0, 2147483647[ | 1440 |  |
| ssl-truststore-location | Oui | String | Chemin du fichier de certificat, pour l'authentification. Celui-ci est à placer dans le dossier `resources`. Dans le cas de GOZEN, mettre `carioca.truststore.jks` |  |  | `/workingdir/carioca.truststore.jks` |
| ssl-truststore-password | Oui | String | Mot de passe pour le fichier de certificat. (Vault) |  |  |  |
| ssh-private-key | Non | String | Clef privée pour l'authentification SSH. (Vault) |  |  |  |
| ssh-username | Oui | String | Nom d'utilisateur de pour l'authentification SSH. (Vault) |  |  |  |
| ssh-password | Non | String | Mot de passe pour l'authentification SSH, dans le cas d'une authentification login/password. (Vault) |  |  |  |
| ssh-with-key-pair-authentification | Non | Booléen | Indique le mode de d'authentification. Mettre 'true' pour une connexion par clef publique/privé | `true`, `false` | `true` |  |
| ssh-with-passphrase-authentification | Non | Booléen | Indique le mode de d'authentification par clef pub/priv nécessite une passphrase | `true`, `false` | `true` |  |
| ssh-passphrase | Non | String | Passphrase pour l'authentification par clef publique/privée. (Vault) |  |  |  |
| kafka-security-protocol | Oui | String | Protocole de sécurité utilisé pour la connexion à Kafka |  | `SASL_SSL` |  |
| kafka-sasl-mechanism | Oui | String | Mécanisme d'authentification SASL |  | `PLAIN` |  |
| kafka-business-consumer-bootstrap-servers | Oui | String | Adresses des Bootstrap Servers. Dans le cas de plusieurs serveurs les séparer par une virgule |  |  | `broker-1.cagip:9093,broker-2.cagip:9093` |
| kafka-business-consumer-group-id | Oui | String | Nom du consumer group |  |  | `my-business-group-id` |
| kafka-business-consumer-topic-id | Oui | String | Nom du topic |  |  | `my-business-topic` |
| kafka-business-consumer-auto-offset-reset | Oui | String | Offset à partir duquel le consumer va se reset automatiquement si aucun offset n'est déjà present | `earliest`, `latest`, `none` | `earliest` |  |
| kafka-business-consumer-max-poll-records | Integer | String | Nombre maximum de messages pouvant être récupérés en un seul coup depuis le topic. | [0, 2147483647[ | 500 |  |
| kafka-business-consumer-poll-timeout-ms | Non | Integer | Timeout pour l'attente de nouveaux messages dans le topic en millisecondes | [0, 2147483647[ | 300000 |  |
| kafka-business-consumer-username | Oui | String | Nom d'utilisateur utilisé pour la connexion à Kafka. (Vault) |  |  |  |
| kafka-business-consumer-password | Oui | String | Mot de passe utilisé pour la connexion à Kafka. (Vault) |  |  |  |
| kafka-data-check-consumer-bootstrap-servers | Oui | String | Adresses des Bootstrap Servers. Dans le cas de plusieurs serveurs les séparer par une virgule |  |  | `broker-1.cagip:9093,broker-2.cagip:9093` |
| kafka-data-check-consumer-group-id | Oui | String | Nom du consumer group |  |  | `my-check-group-id` |
| kafka-data-check-consumer-topic-id | Oui | String | Nom du topic contenant le nombre de ligne de la synchronisation |  |  | `my-check-topic` |
| kafka-data-check-consumer-auto-offset-reset | Oui | String | Offset à partir duquel le consumer va se reset automatiquement si aucun offset n'est déjà present | `earliest`, `latest`, `none` | `earliest` |  |
| kafka-data-check-consumer-max-poll-records | Integer | String | Nombre maximum de messages pouvant être récupérés en un seul coup depuis le topic | [0, 2147483647[ | 500 |  |
| kafka-data-check-consumer-poll-timeout-ms | Non | Integer | Timeout pour l'attente de nouveaux messages dans le topic en millisecondes | [0, 2147483647[ | 300000 |  |
| kafka-data-check-consumer-username | Oui | String | Nom d'utilisateur utilisé pour la connexion à Kafka. (Vault) |  |  |  |
| kafka-data-check-consumer-password | Oui | String | Mot de passe utilisé pour la connexion à Kafka. (Vault) |  |  |  |
| sftp-host | Oui | String | Adresse IP du serveur SFTP |  |  | `127.0.0.1` |
| sftp-path | Oui | String | Chemin vers le dossier d'output distant |  |  | `/usr/gozen/data/i4i/test/test-dev/out` |
| sftp-path-tmp | Non* | String | Chemin vers le dossier d'output distant. Obligatoire pour le comportement `batch` |  |  | `/usr/gozen/data/i4i/test/test-dev/tmp` |
| sftp-port | Non | Integer | Port du serveur SFTP | [0, 65535] | 22 |  |
| file-name-prefix | Oui | String | Prefix du nom de fichier qui sera généré en sortie |  |  | `my-file` |
| file-enable-timestamp | Non | Booléen | Option pour faire apparaître un Timestamp dans le nom du fichier | `true`, `false` | `false` |  |
| file-timestamp-pattern | Non | String | Format du timestamp dans le nom du fichier | ISO-8601 | `dd-MM-yyyy-HH-mm-ss` | `yyyy-MM-dd` |
| file-output-format | Oui | String | Format du fichier en sortie | `csv`, `json` |  | `csv` |
| file-record-separator | Oui | String | Type de caractère de fin de ligne  | `LF`, `CR`, `CRLF` | `LF` |  |
| csv-data-delimiter | Non | String | Délimiteur des données `csv` |  | `;` | `,` |
| csv-with-data-quote | Non | Booléen | Envelope les données entre quote double `"`, sous la norme RFC 4180  | `true`, `false` | `false` |  |
| json-header | Non | String | Dans le cas d'un format de fichier `json`. possibilité de mettre un header au fichier |  |  | `[` |
| json-footer | Non | String | Dans le cas d'un format de fichier `json`. possibilité de mettre un footer au fichier |  |  | `]` |


### Configurations des logs

Les logs par défauts sont réglés de manière à n'afficher que les logs qui ont un niveau supérieur ou égal à INFO.
Si vous voulez le maximum de logs, vous pouvez régler le niveau de log dans le fichier `log4j2.xml` situé dans le dossier `resources`.

Vous n'avez qu'a remplacer par objet le niveau de logs (DEBUG, INFO, WARN, ERROR).
