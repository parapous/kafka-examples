#!/bin/sh

awk -F"," '{ instructions += $4 + $5; covered += $5 } END { print "Coverage", 100*covered/instructions, "%" }' target/site/jacoco/jacoco.csv
