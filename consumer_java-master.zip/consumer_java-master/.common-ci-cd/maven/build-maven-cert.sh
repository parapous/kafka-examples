#!/bin/bash
keytool -printcert -rfc -sslserver repository.saas.cagip.gca > repository.saas.cagip.gca.pem
keytool -importcert -noprompt \
  -file repository.saas.cagip.gca.pem -alias repository.saas.cagip.gca \
  -keystore maven-truststore.p12 \
  -storetype PKCS12 \
  -storepass changeit
