# We use CI_ENVIRONMENT_SLUG to get a Kubernetes & ArgoCD compliant string for resources.
# However, it's not ONLY the slug of the CI_ENVIRONMENT_NAME (which we use as the base of every naming) -
# it also truncates the name if too long, and appends a random string to avoid conflicts.
#
# So, essentially :
# - The CI_ENVIRONMENT_NAME : Review/RST-592/kube-deployment
# - Will become something like : review-rst-592-ku-u6r8ch
#
# To know more about this, you can start here :
# - https://gitlab.com/gitlab-org/gitlab-foss/-/issues/38073
# - https://gitlab.com/gitlab-org/gitlab-foss/-/issues/31291
# - https://gitlab.com/gitlab-org/gitlab-foss/-/blob/2608e269a528290db1bc6d6c0d97b71b5bc3ff26/app/models/environment.rb#L190-196

function export_argocd_app_name() {
  ARGOCD_APP_NAME=${APP_BASE_NAME}-${CI_ENVIRONMENT_SLUG}
  echo "[DEBUG] ArgoCD App Name : ${ARGOCD_APP_NAME}"
  export ARGOCD_APP_NAME
}

function export_kubernetes_resources_prefix() {
  if [ "$CAGIP_ENVIRONMENT" == "development" ]; then
    export PREFIX=${CI_ENVIRONMENT_SLUG}-
  fi
  echo "[DEBUG] Kubernetes Resources Prefix : ${PREFIX}"
}

function export_docker_image_name() {
if [ "$CAGIP_ENVIRONMENT" == "production-internet" ] || [ "$CAGIP_ENVIRONMENT" == "preproduction-internet" ]; then
export DOCKER_IMAGE=${DOCKER_STABLE_INTERNET_APP_IMAGE_NAME}
else
  if [ "$CAGIP_ENVIRONMENT" == "preproduction" ] || [ "$CAGIP_ENVIRONMENT" == "production" ]; then
    export DOCKER_IMAGE=${DOCKER_STABLE_APP_IMAGE_NAME}
  else
    if  [ "$CAGIP_ENVIRONMENT" == "integration" ]; then
        export DOCKER_IMAGE=${DOCKER_STAGING_APP_IMAGE_NAME}
    else
    export DOCKER_IMAGE=${DOCKER_DEVELOPMENT_APP_IMAGE_NAME}
    fi
  fi
fi
  echo "[DEBUG] Docker Image Name : ${DOCKER_IMAGE}"
}
