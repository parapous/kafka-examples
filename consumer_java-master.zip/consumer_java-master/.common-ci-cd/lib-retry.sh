function retry_until_success_or_timeout() {
  # This function mainly prints debug information to STDERR
  # in order to keep a clean STDOUT with the command's output
  # so it can be called in a subshell to use its STDOUT afterward
  CMD="$*"
  TIMEOUT=120
  echo "Trying command repeatedly until it success or we've been trying for too long." >&2
  echo "Command being retried: ${CMD}" >&2

  for i in $(seq 1 ${TIMEOUT}); do
    echo "[Try $i] $CMD" >&2
    set +e
    OUT="$($@ 2>&1)"
    RC=$?
    set -e
    if [ $RC -eq 0 ]; then
      echo "Command succeeded!" >&2
      break
    else
      echo "Command's Return Code: $?" >&2
      echo "Command's Output: ${OUT}" >&2
      echo "Command failed... Retrying in 2 seconds." >&2
      sleep 2
    fi
  done;
  if [ $RC -ne 0 ]; then
    echo "Command could definitely not succeed. Won't try anymore." >&2
  fi
  echo "$OUT"
  return $RC
}
