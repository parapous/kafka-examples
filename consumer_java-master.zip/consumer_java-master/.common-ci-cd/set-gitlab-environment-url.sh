#!/bin/sh

# Required environment variables :
# - GITLAB_PRIVATE_TOKEN (set in project settings)

# https://gitlab.com/gitlab-org/gitlab-ce/issues/27424

URL=$1

if [ -n "$CI_ENVIRONMENT_URL" ]; then
  echo "CI_ENVIRONMENT_URL already set [$CI_ENVIRONMENT_URL]"
  exit 0
fi

CI_ENVIRONMENT_URL=`echo $URL | tr '[:upper:]' '[:lower:]'`


echo "Setting environment url to "$CI_ENVIRONMENT_URL
env_id=$(curl -ksSL --header "PRIVATE-TOKEN: $GITLAB_PRIVATE_TOKEN" \
  https://scm.sws.group.gca/api/v4/projects/$CI_PROJECT_ID/environments \
  | jq '.[] | select(.name==env.CI_ENVIRONMENT_NAME) | .id')

if [ -n "$env_id" ]; then
  curl -ksS --request PUT \
    --data "external_url=$CI_ENVIRONMENT_URL" \
    --header "PRIVATE-TOKEN: $GITLAB_PRIVATE_TOKEN" \
    "https://scm.sws.group.gca/api/v4/projects/$CI_PROJECT_ID/environments/$env_id"
fi
