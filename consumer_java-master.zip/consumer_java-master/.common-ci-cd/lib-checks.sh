CURRENT_DIR="$( dirname "${BASH_SOURCE[0]}" )"
source ${CURRENT_DIR}/lib-retry.sh

function check_that_live_version_matches_expected_deployed_one {
  URL=$1
  EXPECTED_COMMIT=$2

  echo "Checking that reported version by ${URL} matches expected version commit ID of ${EXPECTED_COMMIT}"

  REPORTED_COMMIT=$(curl -sk ${URL} | jq '.git.commit.id' | tr -d '"')

  echo "reported commit ${REPORTED_COMMIT}"
  if [ "${REPORTED_COMMIT}" = "${EXPECTED_COMMIT}" ]; then
    echo "[SUCCESS] Verified commit ID of ${REPORTED_COMMIT}"
    return 0
  else
    echo "[FAILED] Expected commit ID ${EXPECTED_COMMIT} but got ${REPORTED_COMMIT}"
    return 2
  fi
}

 function wait_for_live_version_to_match_expected_deployed_one_for_all_ingresses {
  DURATION=${1:-120} # In seconds

  echo "Checking that live version matches expected deployed one for all ingresses"
  for host in $INGRESS_HOST; do
    echo "Trying Ingress host ${host} until success or timeout of $((${DURATION}*2))s"
    for i in $(seq 1 ${DURATION}); do
      set +e
      check_that_live_version_matches_expected_deployed_one \
        ${host}/actuator/info \
        "$(echo ${CI_COMMIT_SHA} | head -c7)"
      MATCHES=$?
      set -e
      if [ "$MATCHES" = "0" ]; then
        echo "[SUCCESS]"
        return 0
      else
        echo "[FAIL]"
        sleep 2
      fi
    done
  done
 }

