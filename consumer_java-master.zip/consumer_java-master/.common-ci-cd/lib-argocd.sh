CURRENT_DIR="$( dirname "${BASH_SOURCE[0]}" )"
source ${CURRENT_DIR}/lib-retry.sh

function generate_argocd_config() {
  envsubst < ./.common-ci-cd/argocd-config-template.yaml > ./argocd-config.yaml
}

function discover_ingress_host_from_argocd_manifests {
  echo "ArgoCD debug information :
  - App Name : ${ARGOCD_APP_NAME}"
  INGRESS_HOSTS="https://$(retry_until_success_or_timeout argocd app manifests ${ARGOCD_APP_NAME} \
    | grep '^  - host: ' | grep -oE '[^ ]+$')"
  echo "Got the following Ingress Hosts from ArgoCD manifests:"

 for host in $INGRESS_HOSTS; do
  echo "- $host"
 done

 NUMBER_OF_INGRESS_HOSTS=$(echo ${INGRESS_HOSTS}  | wc -l)
 if [ $NUMBER_OF_INGRESS_HOSTS -gt 1 ]; then
   echo "[WARNING] We have discovered more than one Ingress Hosts. Truncating to only one."
   INGRESS_HOST=$(echo ${INGRESS_HOSTS} | head -n1)
 else
  INGRESS_HOST=${INGRESS_HOSTS}
 fi

export INGRESS_HOST
}
