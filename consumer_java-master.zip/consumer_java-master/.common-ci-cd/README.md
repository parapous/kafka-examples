# Common CI/CD

This repository contains scripts and resources used by multiple projects in their `.gitlab-ci.yml` files.

