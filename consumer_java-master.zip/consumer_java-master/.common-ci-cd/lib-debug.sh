function debug_display_generic_variables() {
  echo "[DEBUG] Generic variables used in CI pipeline:
  - Entity Name: ${ENTITY_NAME}
  - Project Code: ${PROJECT_CODE}
  - App Base Name: ${APP_BASE_NAME}
  - CI Commit Hash: ${CI_COMMIT_SHA}
  - CI Commit Slug: ${CI_COMMIT_REF_SLUG}
  - Environment: ${CI_ENVIRONMENT_NAME}
  - Environment Slug: ${CI_ENVIRONMENT_SLUG}
  - Cagip Environment: ${CAGIP_ENVIRONMENT}"
}

function debug_display_argocd_variables() {
  echo "[DEBUG] ArgoCD variables used in CI pipeline:
  - Project   : ${PROJECT_CODE}-${CAGIP_ENVIRONMENT}
  - Namespace : ${PROJECT_CODE}-${CAGIP_ENVIRONMENT}
  - CI Project URL : ${CI_PROJECT_URL}
  - Config File:
$(cat ./argocd-config.yaml)"
}

function debug_display_promote_api_variables() {
  CURRENT_DIR="$( dirname "${BASH_SOURCE[0]}" )"
  PROMOTE_CONFIG=$(envsubst < ${CURRENT_DIR}/promote-config-template.curl)
  PROMOTE_PAYLOAD=$(envsubst < ${CURRENT_DIR}/promote-payload-template.json)

  echo "[DEBUG] Promote API variables used in CI pipeline:
  - Token                   : ${TOKEN}
  - Promote URL             : ${PROMOTE_URL}
  - Artifactory Staging REPO  : ${RAW_ARTIFACTORY_STAGING_REPO}
  - Artifactory Stable REPO : ${RAW_ARTIFACTORY_STABLE_REPO}
  - Promote Data            : ${PROMOTE_DATA}
  - Promote Config          :
${PROMOTE_CONFIG}
  - Promote JSON Payload          :
${PROMOTE_PAYLOAD}"
}

