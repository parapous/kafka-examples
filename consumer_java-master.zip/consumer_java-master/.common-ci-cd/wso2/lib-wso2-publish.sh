function create_wso2_api() {
  echo "Trying to create and publish ${WSO2_CONTEXT} API in WSO2"

  CURRENT_DIR="$(dirname "${BASH_SOURCE[0]}")"
  envsubst <${CURRENT_DIR}/create-api-payload-template.json >./create-api-payload.json
  envsubst <${CURRENT_DIR}/create-api-config-template.curl >./create-api-config.curl
  curl --config ./create-api-config.curl
}

function check_wso2_api() {
  echo "Check if ${WSO2_CONTEXT} API is created in WSO2"

  export WSO2_GET_API_STATUS_CODE=$(
    curl -k -s -o /dev/null "${WSO2_API_URL}/api?name=${WSO2_API_NAME}&version=${WSO2_API_VERSION}" \
    -w "%{http_code}" \
    -H "accept: application/json" \
    -H "entite: LCL" \
    -H "instance: ${WSO2_INSTANCE}"
  )
}

function update_wso2_api() {
  echo "Update ${WSO2_CONTEXT} API in WSO2"

  CURRENT_DIR="$(dirname "${BASH_SOURCE[0]}")"
  envsubst <${CURRENT_DIR}/update-api-payload-template.json >./update-api-payload.json
  envsubst <${CURRENT_DIR}/update-api-config-template.curl >./update-api-config.curl
  curl --config ./update-api-config.curl
}

function create_or_update_wso2_api() {
  check_wso2_api
  echo "Status code ${WSO2_GET_API_STATUS_CODE}"

  if [ ${WSO2_INSTANCE} == "HPROD" ]; then
    export WSO2_APP_URL_PROD=${WSO2_APP_URL_INTEGRATION}
    export WSO2_APP_URL_SBOX=${WSO2_APP_URL_INTEGRATION}
    export WSO2_GATEWAY_ENVIRONMENTS="Production and Sandbox"
  else
    export WSO2_APP_URL_PROD=${WSO2_APP_URL_PROD}
    export WSO2_APP_URL_SBOX=${WSO2_APP_URL_SBOX}
    export WSO2_GATEWAY_ENVIRONMENTS="Intranet,Internet"
  fi

  if [ ${WSO2_GET_API_STATUS_CODE} == "200" ]; then
    echo "${WSO2_CONTEXT} API is already published!" >&2
    update_wso2_api
    get_swagger_api
    update_swagger_api
  else
    get_swagger_api
    create_wso2_api
  fi
}

function get_swagger_api(){
  echo "GET LAST SWAGGER API VERSION"
  export WSO2_SWAGGER_API_CONTENT=$(curl -k ${WSO2_APP_URL_SBOX}/service-api | sed 's/"openapi":"[0-9.]\+"/"openapi":"3.0.0"/')
}

function update_swagger_api(){
  echo "Update SWAGGER ${WSO2_CONTEXT} API in WSO2"
  CURRENT_DIR="$(dirname "${BASH_SOURCE[0]}")"
  envsubst <${CURRENT_DIR}/update-swagger-api-payload-template.json >./update-swagger-api-payload.json
  envsubst <${CURRENT_DIR}/update-swagger-api-config-template.curl >./update-swagger-api-config.curl
  curl --config ./update-swagger-api-config.curl
}
