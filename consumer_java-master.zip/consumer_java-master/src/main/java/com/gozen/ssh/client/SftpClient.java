package com.gozen.ssh.client;

import com.gozen.ssh.channel.SftpChannel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import org.apache.kafka.common.utils.ByteBufferInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

/**
 * SFTP Client for SFTP server
 */
public class SftpClient implements AutoCloseable {

    // Logger class
    private final Logger logger = LoggerFactory.getLogger(SftpClient.class);
    // SFTP channel
    private SftpChannel channel;

    public SftpClient() throws JSchException {
        channel = new SftpChannel();
    }

    /**
     * Writes data in distant file
     * @param file path to the file
     * @param data data to write
     */
    public void writeDataInFile(Path file, String data) throws SftpException, IOException, JSchException {
        if(data==null || data.isEmpty()) return;
        ByteBuffer buffer = StandardCharsets.UTF_8.encode(data);
        try (InputStream stream = new ByteBufferInputStream(buffer)){
            channel.getSftpChannel().put(stream, file.toString(), ChannelSftp.APPEND);
        }
    }

    /**
     * Get files list from distant folder path
     * @param folder path of folder
     * @return list of all files into the folder
     * @throws SftpException unable to list files in folder
     */
    public List<Path> getFilesFromPath(Path folder) throws SftpException, JSchException {

        channel.getSftpChannel().cd(folder.toString());
        Vector<ChannelSftp.LsEntry> files = channel.getSftpChannel().ls(folder.toString());

        return files.stream().map(ChannelSftp.LsEntry::getFilename)
                .filter(f -> f.contains(".json") || f.contains(".csv"))
                .map(Paths::get)
                .collect(Collectors.toList());
    }

    /**
     * Delete a file
     * @param file path of file to delete
     * @throws SftpException can't delete file
     */
    public void deleteFile(Path file) throws SftpException, JSchException {
        logger.debug("Deleting file :" + file);
        channel.getSftpChannel().rm(file.toString());
    }

    /**
     * Delete all files listed
     * @param files list of files to delete
     * @throws SftpException some files can't be delete
     */
    public void deleteFiles(List<Path> files) throws SftpException, JSchException {
        for (Path file : files) deleteFile(file);
    }

    /**
     * Delete all files in the folder
     * @param folder path of folder to clear
     * @throws SftpException some files can't be delete
     */
    public void deleteFilesFolder(Path folder) throws SftpException, JSchException {
        deleteFiles(getFilesFromPath(folder));
        logger.debug("Files from folder '" + folder + "' was successfully deleted.");
    }

    /**
     * Close SFTP client
     */
    @Override
    public void close() {
        channel.close();
    }
}
