package com.gozen.ssh;

import com.gozen.context.Context;
import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.util.Properties;

/**
 * Auto-manage SFTP session
 * Open new session if necessary.
 * Support to connection mode :
 * - Login/password
 * - Private/public keys
 */
public class SshSession implements Closeable {

    private static final Logger logger = LoggerFactory.getLogger(SshSession.class);

    private final JSch jsch = new JSch();

    private Session session;
    private final Properties sessionProperties = new Properties();

    private final String host = Context.getInstance().getSftpHost();
    private final int port = Context.getInstance().getSftpPort();
    private final String username = Context.getInstance().getSshUsername();
    private final String password  = Context.getInstance().getSshPassword();

    private static SshSession instance;

    public static SshSession getInstance() throws JSchException {
        if(instance==null) instance = new SshSession();
        return instance;
    }

    /**
     * Build a SSH session
     * @throws JSchException issue with authentification configuration
     */
    private SshSession() throws JSchException {

        sessionProperties.put("StrictHostKeyChecking", "no");  // Disables host key verification

        // Configure SSH keys if this mode is activated
        if(Context.getInstance().isKeyPairAuthentification()){
            if(Context.getInstance().isPassphraseAuthentification()){
                jsch.addIdentity("SFTP-Consumer", Context.getInstance().getSshPrivateKey().getBytes(), null, Context.getInstance().getSshPassphrase().getBytes());
            }else{
                jsch.addIdentity("SFTP-Consumer", Context.getInstance().getSshPrivateKey().getBytes() , null, null);
            }
        }
    }

    /**
     * Get an active SSH session
     * @return a connected SSH session
     * @throws JSchException issue when connect to SSH server
     */
    public Session getSession() throws JSchException {
        if(!isConnected()){
            logger.info("No connected session found, try to connect..");
            connect();
        }
        return session;
    }

    /**
     * Create session and connect to SFTP Server
     * @throws JSchException can't create and connect to SFTP session
     */
    private void connect() throws JSchException {
        // properly close session
        close();

        logger.info("Connecting to server...");

        session = jsch.getSession(username, host);
        // Configure password if this connection mode is activated
        if(!Context.getInstance().isKeyPairAuthentification()){
            session.setPassword(password);
        }
        session.setPort(port);
        session.setConfig(sessionProperties);
        session.connect();

        logger.info("Successfully connected to server.");
    }

    /**
     * Check if sessions and channel are open
     * @return true if connection is open
     */
    public boolean isConnected(){
        return (session!=null && session.isConnected());
    }

    /**
     * Close connection to SFTP Server
     */
    @Override
    public void close() {
        if(isConnected()) logger.info("Disconnecting from SFTP server...");
        if(session != null) session.disconnect();
    }
}
