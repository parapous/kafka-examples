package com.gozen.ssh.channel;

import com.gozen.ssh.SshSession;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wrapper for jcraft.ChannelSftp with autoconnect
 */
public class SftpChannel implements AutoCloseable {

    private final Logger logger = LoggerFactory.getLogger(SftpChannel.class);

    // SFTP Channel to manage file on server
    private ChannelSftp channelSftp;

    // SSH Session
    private SshSession session;

    public SftpChannel() throws JSchException {
        session = SshSession.getInstance();
    }

    /**
     * Get unwrapped SFTP channel
     * @return Channel SFTP
     * @throws JSchException can't get valid SFTP Channel
     */
    public ChannelSftp getSftpChannel() throws JSchException {
        if(!isConnected()) connect();
        return channelSftp;
    }

    /**
     * Open and connect SFTP channel
     * @throws JSchException can't open or connect SFTP channel
     */
    private void connect() throws JSchException {
        if(session!= null) {
            logger.info("Opening SFTP channel...");
            channelSftp = (ChannelSftp) session.getSession().openChannel("sftp");
            channelSftp.connect();
            logger.info("SFTP channel connected");
        }
    }

    /**
     * Check if channelSftp is open
     * @return true if connection is open
     */
    public boolean isConnected(){
        return (channelSftp!=null && channelSftp.isConnected());
    }

    /**
     * Close SFTP channel
     */
    @Override
    public void close() {
        if(channelSftp!= null){
            logger.info("Closing SFTP channel...");
            channelSftp.disconnect();
            channelSftp = null;

        }
    }
}
