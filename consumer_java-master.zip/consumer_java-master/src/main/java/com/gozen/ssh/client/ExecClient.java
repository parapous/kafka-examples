package com.gozen.ssh.client;


import com.gozen.ssh.channel.ExecChannel;
import com.jcraft.jsch.JSchException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

/**
 * Exec Client for execute command on server
 */
public class ExecClient implements AutoCloseable {

    // Logger class
    private final Logger logger = LoggerFactory.getLogger(ExecClient.class);

    // Exec channel
    private ExecChannel execChannel;

    public ExecClient() throws JSchException {
        execChannel = new ExecChannel();
    }

    /**
     * Get the number of line of the file with the given path
     * @param file path of file
     * @return number of lines in file
     * @throws Exception error when counting lines
     */
    public int getLinesNumber(Path file) throws Exception {

        String execResponse = execChannel.executeCommand("wc -l < "+file.toString()).replaceAll("\n", "");

        logger.debug("execResponse="+execResponse);

        return Integer.parseInt(execResponse);
    }

    /**
     * Move a file from source path to destination path
     * @param source path to source file
     * @param destination path to destination
     * @throws Exception error when coping file
     */
    public void moveFile(Path source, Path destination) throws Exception {
        execChannel.executeCommand("cp " + source.toString() + " " + destination.toString());
    }

    /**
     * Close Exec channel
     * @throws Exception can't close channel
     */
    @Override
    public void close() throws Exception {
        if(execChannel!=null) execChannel.close();
    }
}
