package com.gozen.ssh.channel;

import com.gozen.ssh.SshSession;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Wrapper for com.gozen.ssh.channel.ExecChannel with autoconnect
 */
public class ExecChannel implements AutoCloseable {

    private final Logger logger = LoggerFactory.getLogger(ExecChannel.class);

    // Exec channel to execute command on server
    ChannelExec channelExec;

    // SSH session
    SshSession session;

    public ExecChannel() throws JSchException {
        session = SshSession.getInstance();
    }

    /**
     * Execute the given command
     * @param command command to execute
     * @return output of command
     * @throws Exception can't execute command
     */
    public String executeCommand(String command) throws Exception {
        if(isConnected()) close();
        openChannel();
        channelExec.setCommand(command);
        connect();
        String response = readResponse();
        close();
        return response;
    }

    /**
     * get unwrapped ChannelExec
     * @return ChannelExec
     */
    public ChannelExec getExecChannel() {
        return channelExec;
    }

    /**
     * Open a Exec channel
     * @throws JSchException can't open Exec channel
     */
    private void openChannel() throws JSchException {
        if(session!= null) {
            logger.info("Opening EXEC channel...");
            channelExec = (ChannelExec) session.getSession().openChannel("exec");
        }
    }

    /**
     * Connect Exec channel
     * @throws JSchException can't connect Exec channel
     */
    private void connect() throws JSchException {
        if(channelExec!= null) {
            channelExec.connect();
            logger.info("EXEC channel connected");
        }
    }

    /**
     * Read output response of commande executed
     * @return command output
     * @throws Exception Can't read command output
     */
    private String readResponse() throws Exception {
        try (InputStream in = channelExec.getInputStream();
             InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8);
             StringWriter stringWriter = new StringWriter())
        {
            while (true) {

                reader.transferTo(stringWriter);
                if (!channelExec.isConnected())
                {
                    if (in.available() > 0) continue;
                    return stringWriter.toString();
                }
                TimeUnit.SECONDS.sleep(1);

            }
        }
    }

    /**
     * Check if channelSftp is open
     * @return true if connection is open
     */
    public boolean isConnected(){
        return (channelExec !=null && channelExec.isConnected());
    }


    /**
     * Close Exec channel
     */
    @Override
    public void close() {
        if (channelExec!=null){
            logger.debug("Closing EXEC channel...");
            channelExec.disconnect();
            channelExec = null;
        }
    }

}
