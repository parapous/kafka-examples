package com.gozen;

import com.gozen.context.Context;
import com.gozen.context.ShutDownThread;
import com.gozen.kafka.consumer.business.BusinessConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Run business
 */
public class ApplicationContext {

    private final Logger logger = LoggerFactory.getLogger(ApplicationContext.class);

    public void run() {

        logger.info("Sftp - Consumer");
        try {

            // build consumer
            logger.info("Creation of consumer");
            BusinessConsumer consumer = new BusinessConsumer("sftp-consumer", Context.getInstance().getConsumerTopics());

            // prepare shutdown hook
            Runtime.getRuntime().addShutdownHook(new ShutDownThread(consumer));

            consumer.run();

        } catch (Throwable e) {
            logger.error("Errors occurs: ", e);
            System.exit(1);
        }

    }


}
