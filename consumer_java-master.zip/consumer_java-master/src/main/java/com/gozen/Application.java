package com.gozen;

/**
 * Main class
 */
public class Application {

    // Entry point
    public static void main(String[] args) {

        ApplicationContext applicationContext = new ApplicationContext();
        applicationContext.run();

    }

}