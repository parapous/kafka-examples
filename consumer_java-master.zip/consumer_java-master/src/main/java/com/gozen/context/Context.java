package com.gozen.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Load and check environment context
 */
public class Context {

    private final Logger logger = LoggerFactory.getLogger(Context.class);

    private final static Context instance = new Context();

    /**
     * Microservice globals
     */

    // Strategy of microservice
    private String microserviceStrategy;

    // Enable/disable check file number of lines between output file generate and lines expected
    // need a kafka topic with number of lines of current sync
    private boolean enableDataCheck = false;

    // Delay before check file in case of check data
    // this delay is start when no more message is find in kafka topic (poll empty)
    private int delayBeforeFileReplacementForBatchMode = 30; // 30 min

    // Delay in minute before replace file in SFTP serveur for new one
    private int delayBeforeFileReplacementForRealtimeMode = 1440; // 24h


    /**
     * TrustStore
     */

    // Trust Store location
    private String sslTrustStoreLocation;

    // SSL Truststore password
    private String sslTruststorePassword;

    /**
     * SSH
     */
    // SSH authentification mode ( Keypair or login/password )
    private boolean isKeyPairAuthentification = true;

    // SSH with passphrase authentification
    private boolean isPassphraseAuthentification = true;

    // SSH Private key
    private String sshPrivateKey;

    // SSH Passphrase
    private String sshPassphrase;

    // SSH Username
    private String sshUsername;

    // SSH Password
    private String sshPassword;

    /**
     * KAFKA globals
     */

    // Security Protocol
    private String kafkaSecurityProtocol = "SASL_SSL";

    // SASL Mechanism
    private String kafkaSaslMechanism = "PLAIN";

    // Kafka key serializer class
    private final String keyDeserializerClass = "org.apache.kafka.common.serialization.StringDeserializer";

    // kafka value serializer class
    private final String valueDeserializerClass = "org.apache.kafka.common.serialization.StringDeserializer";

    /**
     * KAFKA consumer
     */

    // Bootstrap Servers, if you want multiple, separate them with ","
    private String businessConsumerBootstrapServers;

    // Group ID of consumer
    private String businessConsumerGroupId;

    // Topic ID of consumer
    private String businessConsumerTopicId;

    // Auto Offset Reset of consumer
    private String businessConsumerAutoOffsetReset = "earliest";

    // Max poll records, number of messages that consumer will process before giving back control to the main software (default 100)
    private int businessConsumerMaxPollRecords = 500;

    // Poll timeout in ms
    private int businessConsumerPollTimeoutMs = 300000; // 5min

    // SASL Jaas consumer Username
    private String businessConsumerSaslJaasUsername;

    // SASL Jaas consumer Password
    private String businessConsumerSaslJaasPassword;

    /**
     * KAFKA file lines number consumer
     */

    // Bootstrap Servers for lines number consumer, if you want multiple, separate them with ","
    private String dataCheckConsumerBootstrapServers;

    // Group ID of lines number consumer
    private String dataCheckConsumerGroupId;

    // Topic ID of lines number consumer
    private String dataCheckConsumerTopicId;

    // Auto Offset Reset of lines number consumer
    private String dataCheckConsumerAutoOffsetReset = "earliest";

    // Max poll records, number of messages that consumer will process before giving back control to the main software (default 100)
    private int dataCheckConsumerMaxPollRecords = 500;

    private int dataCheckConsumerPollTimeoutMs = 300000; // 5min

    // SASL Jaas lines number consumer Username
    private String dataCheckConsumerSaslJaasUsername;

    // SASL Jaas lines number consumer Password
    private String dataCheckConsumerSaslJaasPassword;

    /**
     * SFTP serveur
     */

    // SFTP Host
    private String sftpHost;

    // SFTP Path
    private String sftpPath;

    // SFTP temporary Path
    private String sftpPathTmp;

    // SFTP Port
    private int sftpPort = 22;

    /**
     * Files config
     */

    // Output file prefix
    private String filePrefix;

    // File timestamp
    private boolean fileTimestamp = false;

    // File timestamp pattern
    private String fileTimestampPattern = "dd-MM-yyyy-HH-mm-ss";

    // File output format
    private String fileOutputFormat;

    // File record separator, examples "\n" or "\r\n"
    private String fileRecordSeparator;

    /**
     * CSV file
     */
    // The CSV data delimiter
    private String csvDataDelimiter = ";";

    // CSV data wrap in double quote (RFC 4180)
    private boolean csvWithDataQuote = false;


    /**
     * JSON File
     */

    // JSON File header
    private String jsonHeader;

    // JSON File footer
    private String jsonFooter;

    private Context() {
        try {
            loadContext();
            checkContext();
        } catch (Exception e) {
            logger.error("Error when context loading..."+ e.getMessage());
            System.exit(1);
        }
    }

    public static Context getInstance(){
          return instance;
    }

    private void loadContext() {
        logger.info("Context Loading...");

        // Microservice
        microserviceStrategy = System.getenv("microservice-strategy");
        enableDataCheck = System.getenv("microservice-enable-data-check") != null ? Boolean.parseBoolean(System.getenv("microservice-enable-data-check")) : enableDataCheck;
        delayBeforeFileReplacementForBatchMode = System.getenv("microservice-strategy-batch-delay-before-file-replacement") != null ? Integer.parseInt(System.getenv("microservice-strategy-batch-delay-before-file-replacement")) : delayBeforeFileReplacementForBatchMode;
        delayBeforeFileReplacementForRealtimeMode = System.getenv("microservice-strategy-realtime-delay-before-file-replacement") != null ? Integer.parseInt(System.getenv("microservice-strategy-realtime-delay-before-file-replacement")) : delayBeforeFileReplacementForRealtimeMode;

        // Truststore
        sslTrustStoreLocation = System.getenv("ssl-truststore-location");
        sslTruststorePassword = System.getenv("ssl-truststore-password");

        // SSH
        isKeyPairAuthentification = System.getenv("ssh-with-key-pair-authentification") != null ? Boolean.parseBoolean(System.getenv("ssh-with-key-pair-authentification")) : isKeyPairAuthentification;
        isPassphraseAuthentification = System.getenv("ssh-with-passphrase-authentification") != null ? Boolean.parseBoolean(System.getenv("ssh-with-passphrase-authentification")) : isPassphraseAuthentification;
        sshPrivateKey = System.getenv("ssh-private-key");
        sshPassphrase = System.getenv("ssh-passphrase");
        sshUsername = System.getenv("ssh-username");
        sshPassword = System.getenv("ssh-password");

        // Kafka globals config
        kafkaSecurityProtocol = System.getenv("kafka-security-protocol") != null ? System.getenv("kafka-security-protocol") : kafkaSecurityProtocol;
        kafkaSaslMechanism = System.getenv("kafka-sasl-mechanism") != null ? System.getenv("kafka-sasl-mechanism") : kafkaSaslMechanism;

        // Kafka business consumer config
        businessConsumerBootstrapServers = System.getenv("kafka-business-consumer-bootstrap-servers");
        businessConsumerGroupId = System.getenv("kafka-business-consumer-group-id");
        businessConsumerTopicId = System.getenv("kafka-business-consumer-topic-id");
        businessConsumerAutoOffsetReset = System.getenv("kafka-business-consumer-auto-offset-reset") != null ? System.getenv("kafka-business-consumer-auto-offset-reset") : businessConsumerAutoOffsetReset;
        businessConsumerMaxPollRecords = System.getenv("kafka-business-consumer-max-poll-records") != null ? Integer.parseInt(System.getenv("kafka-business-consumer-max-poll-records")) : businessConsumerMaxPollRecords;
        businessConsumerPollTimeoutMs = System.getenv("kafka-business-consumer-poll-timeout-ms") != null ? Integer.parseInt(System.getenv("kafka-business-consumer-poll-timeout-ms")) : businessConsumerPollTimeoutMs;
        businessConsumerSaslJaasUsername = System.getenv("kafka-business-consumer-username");
        businessConsumerSaslJaasPassword = System.getenv("kafka-business-consumer-password");

        // Kafka consumer config
        dataCheckConsumerBootstrapServers = System.getenv("kafka-data-check-consumer-bootstrap-servers");
        dataCheckConsumerGroupId = System.getenv("kafka-data-check-consumer-group-id");
        dataCheckConsumerTopicId = System.getenv("kafka-data-check-consumer-topic-id");
        dataCheckConsumerAutoOffsetReset = System.getenv("kafka-data-check-consumer-auto-offset-reset") != null ? System.getenv("kafka-data-check-consumer-auto-offset-reset") : dataCheckConsumerAutoOffsetReset;
        dataCheckConsumerMaxPollRecords = System.getenv("kafka-data-check-consumer-max-poll-records") != null ? Integer.parseInt(System.getenv("kafka-data-check-consumer-max-poll-records")) : dataCheckConsumerMaxPollRecords;
        dataCheckConsumerPollTimeoutMs = System.getenv("kafka-data-check-consumer-poll-timeout-ms") != null ? Integer.parseInt(System.getenv("kafka-data-check-consumer-poll-timeout-ms")) : dataCheckConsumerPollTimeoutMs;
        dataCheckConsumerSaslJaasUsername = System.getenv("kafka-data-check-consumer-username");
        dataCheckConsumerSaslJaasPassword = System.getenv("kafka-data-check-consumer-password");

        // SFTP serveur config
        sftpHost = System.getenv("sftp-host");
        sftpPath = System.getenv("sftp-path");
        sftpPathTmp = System.getenv("sftp-path-tmp");
        sftpPort = System.getenv("sftp-port") != null ? Integer.parseInt(System.getenv("sftp-port")) : sftpPort;

        // Files config
        filePrefix = System.getenv("file-name-prefix");
        fileTimestamp = System.getenv("file-enable-timestamp") != null ? Boolean.parseBoolean(System.getenv("file-enable-timestamp")) : fileTimestamp;
        fileTimestampPattern = System.getenv("file-timestamp-pattern") != null ? System.getenv("file-timestamp-pattern") : fileTimestampPattern;
        fileOutputFormat = System.getenv("file-output-format");
        fileRecordSeparator = System.getenv("file-record-separator");

        // CSV file
        csvDataDelimiter = System.getenv("csv-data-delimiter") != null ? System.getenv("csv-data-delimiter") : csvDataDelimiter;
        csvWithDataQuote = System.getenv("csv-with-data-quote") != null ? Boolean.parseBoolean(System.getenv("csv-with-data-quote")) : csvWithDataQuote;

        // JSON file
        jsonHeader = System.getenv("json-header");
        jsonFooter = System.getenv("json-footer");

    }

    private void checkContext() {

        // Mandatory config
        boolean stop = false;

        // Microservice

        if (microserviceStrategy == null || microserviceStrategy.isEmpty()) {
            logger.error("Missing microservice strategy config!");
            stop = true;
        }else if(!Constant.microserviceStrategies.contains(microserviceStrategy)){
            logger.error("Strategy unknown ! Please read documentation.");
            stop = true;
        }else {

            // with data check
            if(isEnableDataCheck()){

                // Check config when data check is enable
                if (dataCheckConsumerBootstrapServers == null || dataCheckConsumerBootstrapServers.isEmpty()) {
                    logger.error("Missing check lines consumer bootstrap servers config!");
                    stop = true;
                }

                if (dataCheckConsumerGroupId == null || dataCheckConsumerGroupId.isEmpty()) {
                    logger.error("Missing check lines consumer group ID config!");
                    stop = true;
                }

                if (dataCheckConsumerTopicId == null || dataCheckConsumerTopicId.isEmpty()) {
                    logger.error("Missing check lines consumer topic ID config!");
                    stop = true;
                }

                if (dataCheckConsumerMaxPollRecords < 0) {
                    logger.error("Max poll records for business consumer can't be negative !");
                    stop = true;
                }

                if (dataCheckConsumerPollTimeoutMs < 0) {
                    logger.error("Poll timeout for business consumer can't be negative !");
                    stop = true;
                }

                if (dataCheckConsumerSaslJaasUsername == null || dataCheckConsumerSaslJaasUsername.isEmpty()) {
                    logger.error("Missing check lines consumer SASL JAAS Username config!");
                    stop = true;
                }

                if (dataCheckConsumerSaslJaasPassword == null || dataCheckConsumerSaslJaasPassword.isEmpty()) {
                    logger.error("Missing check lines consumer SASL JAAS Password config!");
                    stop = true;
                }

                if(Constant.batchStrategy.equals(microserviceStrategy)){
                    if (sftpPathTmp == null || sftpPathTmp.isEmpty()) {
                        logger.error("Missing temporary folder location config!");
                        stop = true;
                    }
                }
            }

        }

        if (delayBeforeFileReplacementForBatchMode < 0 || delayBeforeFileReplacementForRealtimeMode < 0) {
            logger.error("Delay before file replacement can't be negative !");
            stop = true;
        }

        // Truststore
        if (sslTrustStoreLocation == null || sslTrustStoreLocation.isEmpty()) {
            logger.error("Missing SSL Truststore Location config!");
            stop = true;
        }

        if (sslTruststorePassword == null || sslTruststorePassword.isEmpty()) {
            logger.error("Missing SSL Truststore Password config!");
            stop = true;
        }

        // Kafka - globals
        if (kafkaSaslMechanism == null || kafkaSaslMechanism.isEmpty()) {
            logger.error("Missing SASL Mechanism config!");
            stop = true;
        }

        if (kafkaSecurityProtocol == null || kafkaSecurityProtocol.isEmpty()) {
            logger.error("Missing Security Protocol config!");
            stop = true;
        }

        // Kafka - consumer
        if (businessConsumerBootstrapServers == null || businessConsumerBootstrapServers.isEmpty()) {
            logger.error("Missing Business Consumer bootstrap servers config!");
            stop = true;
        }

        if (businessConsumerGroupId == null || businessConsumerGroupId.isEmpty()) {
            logger.error("Missing Business Consumer group ID config!");
            stop = true;
        }

        if (businessConsumerTopicId == null || businessConsumerTopicId.isEmpty()) {
            logger.error("Missing Business Consumer topic ID config!");
            stop = true;
        }

        if (businessConsumerAutoOffsetReset == null || businessConsumerAutoOffsetReset.isEmpty()) {
            logger.error("Missing Business Consumer auto offset reset config!");
            stop = true;
        }

        if (businessConsumerMaxPollRecords < 0) {
            logger.error("Max poll records for business consumer can't be negative !");
            stop = true;
        }

        if (businessConsumerPollTimeoutMs < 0) {
            logger.error("Poll timeout for business consumer can't be negative !");
            stop = true;
        }

        if (businessConsumerSaslJaasUsername == null || businessConsumerSaslJaasUsername.isEmpty()) {
            logger.error("Missing Business Consumer SASL JAAS consumer Username config!");
            stop = true;
        }

        if (businessConsumerSaslJaasPassword == null || businessConsumerSaslJaasPassword.isEmpty()) {
            logger.error("Missing Business Consumer SASL JAAS consumer Password config!");
            stop = true;
        }

        // SFTP
        if (sftpHost == null || sftpHost.isEmpty()) {
            logger.error("Missing SFTP IP address config!");
            stop = true;
        }

        if (sshUsername == null || sshUsername.isEmpty()) {
            logger.error("Missing SFTP username config!");
            stop = true;
        }

        if (sftpPort < 0 || sftpPort > 65535) {
            logger.error("SFTP port have to be ranged in [0, 65535] !");
            stop = true;
        }

        // Files
        if (filePrefix == null || filePrefix.isEmpty()) {
            logger.error("Missing file prefix config!");
            stop = true;
        }

        if (fileOutputFormat == null || fileOutputFormat.isEmpty()) {
            logger.error("Missing file output format config!");
            stop = true;
        } else if (! Constant.availableFileFormat.contains(fileOutputFormat.toLowerCase())){
            logger.error("Unknown file output format !");
        }else{
            if(Constant.CSV.equalsIgnoreCase(fileOutputFormat)){
                if (csvDataDelimiter == null || csvDataDelimiter.isEmpty()) {
                    logger.error("Missing CSV delimiter config!");
                    stop = true;
                }
            }
        }

        if (fileRecordSeparator == null || fileRecordSeparator.isEmpty()) {
            logger.error("Missing file record separator config!");
            stop = true;
        }

        // Stop application if missing mandatory fields
        if(stop){
            logger.error("Mandatory field(s) is missing !");
            logger.error("Application will stop.");
            System.exit(1);
        }
    }

    // Getters and Setters
    public String getMicroserviceStrategy() {
        return microserviceStrategy;
    }

    public boolean isEnableDataCheck() {
        return enableDataCheck;
    }

    public int getDelayBeforeFileReplacementForBatchMode() {
        return delayBeforeFileReplacementForBatchMode;
    }

    public int getDelayBeforeFileReplacementForRealtimeMode() {
        return delayBeforeFileReplacementForRealtimeMode;
    }

    public String getBusinessConsumerBootstrapServers() {
        return businessConsumerBootstrapServers;
    }

    public String getBusinessConsumerTopicId() {
        return businessConsumerTopicId;
    }

    public String getBusinessConsumerGroupId() {
        return businessConsumerGroupId;
    }

    public String getBusinessConsumerAutoOffsetReset() {
        return businessConsumerAutoOffsetReset;
    }

    public int getBusinessConsumerMaxPollRecords() {
        return businessConsumerMaxPollRecords;
    }

    public int getBusinessConsumerPollTimeoutMs() {
        return businessConsumerPollTimeoutMs;
    }

    public String getSslTruststorePassword() {
        return sslTruststorePassword;
    }

    public String getKafkaSecurityProtocol() {
        return kafkaSecurityProtocol;
    }

    public String getBusinessConsumerSaslJaasUsername() {
        return businessConsumerSaslJaasUsername;
    }

    public String getBusinessConsumerSaslJaasPassword() {
        return businessConsumerSaslJaasPassword;
    }

    public String getSslTrustStoreLocation() {
        return sslTrustStoreLocation;
    }

    public String getKafkaSaslMechanism() {
        return kafkaSaslMechanism;
    }

    public String getKeyDeserializerClass() {
        return keyDeserializerClass;
    }

    public String getValueDeserializerClass() {
        return valueDeserializerClass;
    }

    public String getDataCheckConsumerBootstrapServers() {
        return dataCheckConsumerBootstrapServers;
    }

    public String getDataCheckConsumerGroupId() {
        return dataCheckConsumerGroupId;
    }

    public String getDataCheckConsumerTopicId() {
        return dataCheckConsumerTopicId;
    }

    public String getDataCheckConsumerAutoOffsetReset() {
        return dataCheckConsumerAutoOffsetReset;
    }

    public int getDataCheckConsumerMaxPollRecords() {
        return dataCheckConsumerMaxPollRecords;
    }

    public int getDataCheckConsumerPollTimeoutMs() {
        return dataCheckConsumerPollTimeoutMs;
    }

    public String getDataCheckConsumerSaslJaasUsername() {
        return dataCheckConsumerSaslJaasUsername;
    }

    public String getDataCheckConsumerSaslJaasPassword() {
        return dataCheckConsumerSaslJaasPassword;
    }

    public String getSftpHost() {
        return sftpHost;
    }

    public String getSshUsername() {
        return sshUsername;
    }

    public String getSshPassword() {
        return sshPassword;
    }

    public String getSftpPath() {
        return sftpPath;
    }

    public String getSftpPathTmp() {
        return sftpPathTmp;
    }

    public int getSftpPort() {
        return sftpPort;
    }

    public String getFilePrefix() {
        return filePrefix;
    }

    public boolean isFileTimestamp() {
        return fileTimestamp;
    }

    public String getFileTimestampPattern() {
        return fileTimestampPattern;
    }

    public String getSshPrivateKey() {
        return sshPrivateKey;
    }

    public boolean isKeyPairAuthentification() {
        return isKeyPairAuthentification;
    }

    public String getSshPassphrase() {
        return sshPassphrase;
    }

    public boolean isPassphraseAuthentification() {
        return isPassphraseAuthentification;
    }

    public String getFileOutputFormat() {
        return fileOutputFormat.toLowerCase();
    }

    public String getFileRecordSeparator() {
        if ("LF".equalsIgnoreCase(fileRecordSeparator)) {
            return "" + Constant.LF;
        } else if ("CR".equalsIgnoreCase(fileRecordSeparator)) {
            return "" + Constant.CR;
        } else if ("CRLF".equalsIgnoreCase(fileRecordSeparator)) {
            return "" + Constant.CR + Constant.LF;
        }else {
            return "" + Constant.LF;
        }
    }

    public String getCsvDataDelimiter() {
        return csvDataDelimiter;
    }

    public boolean isCsvWithDataQuote() {
        return csvWithDataQuote;
    }

    public String getJsonHeader() {
        return jsonHeader;
    }

    public String getJsonFooter() {
        return jsonFooter;
    }

    public List<String> getConsumerTopics() {
        List<String> topics = new ArrayList<>();
        topics.add(getBusinessConsumerTopicId());
        return topics;
    }


}
