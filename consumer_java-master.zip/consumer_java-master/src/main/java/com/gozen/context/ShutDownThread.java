package com.gozen.context;

import com.gozen.kafka.consumer.business.BusinessConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Thread is executed when JVM is shutting down
 */
public class ShutDownThread extends Thread{

    private final Logger logger = LoggerFactory.getLogger(ShutDownThread.class);

    // Consumer to shutdown
    BusinessConsumer consumer;

    public ShutDownThread(BusinessConsumer consumer){
        this.consumer = consumer;
    }


    public void run() {
        logger.info("Shutdown hook is running..");
        if(consumer!=null) {
            logger.info("Closing " + consumer.getClass());
            try {
                consumer.close();
            } catch (Exception e) {
                logger.error("", e);
            }
        }

        logger.info("Shutdown hook is terminated");
    }



}
