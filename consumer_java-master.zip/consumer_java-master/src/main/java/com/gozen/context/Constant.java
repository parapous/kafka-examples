package com.gozen.context;

import java.util.List;

public class Constant {


    public final static String batchStrategy = "batch";
    public final static String realtimeStrategy = "realtime";

    public final static List<String> microserviceStrategies = List.of(batchStrategy, realtimeStrategy);

    public final static char CR  = (char) 0x0D;
    public final static char LF  = (char) 0x0A;

    public final static String CSV = "csv";
    public final static String JSON = "json";

    public final static List<String> availableFileFormat = List.of(CSV, JSON);


}
