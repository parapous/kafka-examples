package com.gozen.kafka.consumer.business.strategy.impl;

import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategy;
import com.gozen.ssh.client.SftpClient;
import com.jcraft.jsch.JSchException;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class InactivityStrategy implements ConsumerStrategy {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final SftpClient sftpClient;

    private Instant inactivityTimeout = Instant.EPOCH;

    private boolean isInactive = false;

    private String filename;

    public InactivityStrategy() throws JSchException {
        this.sftpClient = new SftpClient();
    }

    @Override
    public void process(KafkaConsumer<String, String> consumer, FileFormatter fileFormatter) throws Exception {
        logger.debug("Processing inactivity strategy ..");

        for (int i = 0; i < 10; i++) {

            logger.debug("Polling ..");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getBusinessConsumerPollTimeoutMs()));

            // if poll is empty,
            if(records.isEmpty()) {
                logger.debug("Empty poll ..");
                // if inactivity timeout is passed
                if(Instant.now().isAfter(inactivityTimeout) && !isInactive){
                    // build Footer
                    logger.debug("Add file footer ..");
                    sftpClient.writeDataInFile(Paths.get(Context.getInstance().getSftpPath(), getFilename()), fileFormatter.getFooter());
                    isInactive = true;
                }
                // disconnect the session
                sftpClient.close();
                continue;
            }

            // setup records to convert into good file format
            fileFormatter.setRecords(records);

            // delete files if time is out
            if(Instant.now().isAfter(inactivityTimeout)){
                logger.debug("Delete existing files in target folder ..");
                sftpClient.deleteFilesFolder(Paths.get(Context.getInstance().getSftpPath()));
                filename = generateFilename();

                // build Header
                logger.debug("Add file header ..");
                sftpClient.writeDataInFile(Paths.get(Context.getInstance().getSftpPath(), getFilename()), fileFormatter.getHeader());
                isInactive = false;
            }

            // process poll
            for (String record : fileFormatter.getOutputRecords()) {

                sftpClient.writeDataInFile(Paths.get(Context.getInstance().getSftpPath(), getFilename()), record);
                logger.debug("Message appended: "+record);
            }

            logger.debug("Committing offset..");
            consumer.commitSync();

            // refresh inactivity timeout
            inactivityTimeout = Instant.now().plus(Context.getInstance().getDelayBeforeFileReplacementForInactivityMode(), ChronoUnit.MINUTES);
        }
    }

    private String generateFilename(){
        if(Context.getInstance().isFileTimestamp()) {
            return Context.getInstance().getFilePrefix() + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Context.getInstance().getFileTimestampPattern())) + "." +Context.getInstance().getFileOutputFormat();
        }else{
            return Context.getInstance().getFilePrefix() + "." + Context.getInstance().getFileOutputFormat();
        }
    }

    private String getFilename(){
        if(filename==null) filename = generateFilename();
        return filename;
    }

    @Override
    public void close() throws Exception {
        sftpClient.close();
    }

}
