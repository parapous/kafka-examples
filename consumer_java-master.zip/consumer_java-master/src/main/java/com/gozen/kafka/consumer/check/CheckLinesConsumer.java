package com.gozen.kafka.consumer.check;

import com.gozen.context.Context;
import com.gozen.kafka.KafkaCredentials;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class CheckLinesConsumer implements AutoCloseable{

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final KafkaConsumer<String, String> consumer = null;

    private final String consumerName;

    public CheckLinesConsumer(String consumerName) {

        this.consumerName = consumerName;

//        final Properties props = new Properties();
//        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, Context.getInstance().getCheckLinesConsumerBootstrapServers());
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, Context.getInstance().getCheckLinesConsumerGroupId());
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getKeyDeserializerClass());
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getValueDeserializerClass());
//        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, Context.getInstance().getCheckLinesConsumerMaxPollRecords());
//        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, Context.getInstance().getCheckLinesConsumerAutoOffsetReset());
//        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
//
//        props.put("security.protocol", Context.getInstance().getKafkaSecurityProtocol());
//        props.put("ssl.truststore.location", Context.getInstance().getSslTrustStoreLocation());
//        props.put("sasl.mechanism", Context.getInstance().getKafkaSaslMechanism());
//        props.put("ssl.truststore.password", Context.getInstance().getSslTruststorePassword());
//
//        Optional<String> saslJaasConfig = KafkaCredentials.buildSaslJaasConfig(Context.getInstance().getCheckLinesConsumerSaslJaasUsername(), Context.getInstance().getCheckLinesConsumerSaslJaasPassword());
//        saslJaasConfig.ifPresent(s -> props.put("sasl.jaas.config", s));
//
//        this.consumer = new KafkaConsumer<>(props);
//
//        consumer.subscribe(List.of(Context.getInstance().getCheckLinesConsumerTopicId()));

        logger.info(consumerName + " initialized.");
    }

    /**
     * Run consumer
     */
    public int run() throws Exception {
        logger.info(consumerName + " is running.");

        Optional<Integer> linesNumber = Optional.empty();

//        try {
//
//            while(true){
//                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getCheckLinesConsumerPollTimeoutMs()));
//
//                if(records.isEmpty()){
//                    if(linesNumber.isEmpty()) throw new Exception("No data in kafka topic for get lines number of the current file to sync");
//                    return linesNumber.get();
//                }
//
//                for (ConsumerRecord<String, String> record : records){
//                    linesNumber = Optional.of(Integer.parseInt(record.value()));
//                }
//
//                logger.debug("Committing offset..");
//                consumer.commitSync();
//            }
//        } catch (Exception e) {
//            close();
//            throw new Exception("Error when reading messages from "+consumerName, e);
//        }

        return 10;
    }


    @Override
    public void close() throws Exception {
        logger.info(consumerName + " closing.");
        //consumer.close();
    }


}
