package com.gozen.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

/**
 * Build Kafka credentials
 */
public class KafkaCredentials {

    private static final Logger logger = LoggerFactory.getLogger(KafkaCredentials.class);

    /**
     * Build SASL JAAS config
     * @param username kafka username
     * @param password kafka password
     * @return Optional with SASL JAAS config or empty Optional if config can't be build
     */
    public static Optional<String> buildSaslJaasConfig(String username, String password){

        if(username == null || password == null || username.isEmpty() || password.isEmpty()) {
            return Optional.empty();
        }

        logger.info("SASL JAAS Username/password detected, creating config...");
        String saslJaasConfig = "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"" + username + "\" password=\"" + password + "\";";
        return Optional.of(saslJaasConfig);

    }
}
