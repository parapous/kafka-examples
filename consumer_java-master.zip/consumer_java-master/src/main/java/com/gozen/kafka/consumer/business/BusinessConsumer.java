package com.gozen.kafka.consumer.business;

import com.gozen.context.Context;
import com.gozen.kafka.KafkaCredentials;
import com.gozen.formatter.FileFormatter;
import com.gozen.formatter.FileFormatterFactory;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategy;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategyFactory;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Business consumer
 * According to configuration different strategies of consumption of data and file format can be process
 */
public class BusinessConsumer implements AutoCloseable {

    private final Logger logger = LoggerFactory.getLogger(BusinessConsumer.class);

    // Kafka consumer
    private final KafkaConsumer<String, String> consumer;

    // consumer name
    private final String consumerName;

    // strategy of consumer
    ConsumerStrategy consumerStrategy;

    public BusinessConsumer(String consumerName, List<String> topics) {

        this.consumerName = consumerName;

        final Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, Context.getInstance().getBusinessConsumerBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, Context.getInstance().getBusinessConsumerGroupId());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getKeyDeserializerClass());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getValueDeserializerClass());
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, Context.getInstance().getBusinessConsumerMaxPollRecords());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, Context.getInstance().getBusinessConsumerAutoOffsetReset());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put("security.protocol", Context.getInstance().getKafkaSecurityProtocol());
        props.put("ssl.truststore.location", Context.getInstance().getSslTrustStoreLocation());
        props.put("sasl.mechanism", Context.getInstance().getKafkaSaslMechanism());
        props.put("ssl.truststore.password", Context.getInstance().getSslTruststorePassword());

        Optional<String> saslJaasConfig = KafkaCredentials.buildSaslJaasConfig(Context.getInstance().getBusinessConsumerSaslJaasUsername(), Context.getInstance().getBusinessConsumerSaslJaasPassword());
        saslJaasConfig.ifPresent(s -> props.put("sasl.jaas.config", s));

        this.consumer = new KafkaConsumer<>(props);

        consumer.subscribe(topics);

        logger.info(consumerName + " initialized.");
    }

    /**
     * Run business consumer
     */
    public void run() throws Exception {
        logger.info(consumerName + " is running.");


        try {

            // Define file format in function of env context
            FileFormatter fileFormatter = FileFormatterFactory.getFileConverter(Context.getInstance().getFileOutputFormat());

            // Define strategy algorithm
            consumerStrategy = ConsumerStrategyFactory.getStrategy(Context.getInstance().getMicroserviceStrategy());
            consumerStrategy.process(consumer, fileFormatter);

        } finally {
            close();
        }
    }


    /**
     * Close all resources
     * @throws Exception can't close resources
     */
    @Override
    public void close() throws Exception {
        logger.info(consumerName + " closing.");
        consumerStrategy.close();
        consumer.unsubscribe();
        consumer.close();
    }
}
