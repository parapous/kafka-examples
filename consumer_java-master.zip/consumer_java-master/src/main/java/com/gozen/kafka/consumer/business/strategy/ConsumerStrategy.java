package com.gozen.kafka.consumer.business.strategy;

import com.gozen.formatter.FileFormatter;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public interface ConsumerStrategy extends AutoCloseable {

    /**
     * Process a strategy of consumption of data form business consumer
     * @param consumer business consumer
     * @param fileFormatter format of file
     * @throws Exception Error during processing
     */
    void process(KafkaConsumer<String, String> consumer, FileFormatter fileFormatter) throws Exception;

}
