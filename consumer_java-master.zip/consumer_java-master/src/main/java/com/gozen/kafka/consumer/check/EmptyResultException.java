package com.gozen.kafka.consumer.check;

public class EmptyResultException extends Exception{

    public EmptyResultException(String message){
        super(message);
    }
}
