package com.gozen.kafka.consumer.business.strategy.impl;

import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategy;
import com.gozen.ssh.client.SftpClient;
import com.jcraft.jsch.JSchException;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class RealtimeStrategy implements ConsumerStrategy {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final SftpClient sftpClient;

    private Instant fileTimeout = Instant.EPOCH;

    private String filename;


    public RealtimeStrategy() throws JSchException {
        this.sftpClient = new SftpClient();
    }

    @Override
    public void process(KafkaConsumer<String, String> consumer, FileFormatter fileFormatter) throws Exception {
        logger.debug("Processing realtime strategy ..");

        for (int i = 0; i < 10; i++) {

            logger.debug("Polling ..");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getBusinessConsumerPollTimeoutMs()));

            // if poll is empty, disconnect the session
            if(records.isEmpty()) {
                logger.debug("Empty poll ..");
                sftpClient.close();
                continue;
            }

            // setup records to convert into good file format
            fileFormatter.setRecords(records);

            // delete files if time is out
            if(Instant.now().isAfter(fileTimeout)){

                logger.debug("Delete existing files in target folder ..");
                sftpClient.deleteFilesFolder(Paths.get(Context.getInstance().getSftpPath()));
                filename = generateFilename();

                // build Header
                sftpClient.writeDataInFile(Paths.get(Context.getInstance().getSftpPath(), getFilename()), fileFormatter.getHeader());

                // refresh file timeout
                fileTimeout = Instant.now().plus(Context.getInstance().getDelayBeforeFileReplacementForRealtimeMode(), ChronoUnit.MINUTES);
            }

            // process poll
            for (String record : fileFormatter.getOutputRecords()) {

                sftpClient.writeDataInFile(Paths.get(Context.getInstance().getSftpPath(), getFilename()), record);

                logger.debug("Message appended: "+record);
            }

            logger.debug("Committing offset..");
            consumer.commitSync();


        }

    }

    private String generateFilename(){
        if(Context.getInstance().isFileTimestamp()) {
            return Context.getInstance().getFilePrefix() + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Context.getInstance().getFileTimestampPattern())) + "." +Context.getInstance().getFileOutputFormat();
        }else{
            return Context.getInstance().getFilePrefix() + "." + Context.getInstance().getFileOutputFormat();
        }
    }

    private String getFilename(){
        if(filename==null) filename = generateFilename();
        return filename;
    }

    @Override
    public void close() throws Exception {
        sftpClient.close();
    }
}
