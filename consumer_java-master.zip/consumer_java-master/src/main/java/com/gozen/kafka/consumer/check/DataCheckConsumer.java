package com.gozen.kafka.consumer.check;

import com.gozen.context.Context;
import com.gozen.kafka.KafkaCredentials;
import com.gozen.kafka.consumer.check.strategy.DataCheckStrategy;
import com.gozen.kafka.consumer.check.strategy.DataCheckStrategyFactory;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Consumer to read expected lines in file from a kafka topic
 */
public class DataCheckConsumer implements AutoCloseable{

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    // Kafka consumer
    private final KafkaConsumer<String, String> consumer;

    // consumer name
    private final String consumerName;

    public DataCheckConsumer(String consumerName) {

        this.consumerName = consumerName;

        final Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, Context.getInstance().getDataCheckConsumerBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, Context.getInstance().getDataCheckConsumerGroupId());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getKeyDeserializerClass());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, Context.getInstance().getValueDeserializerClass());
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, Context.getInstance().getDataCheckConsumerMaxPollRecords());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, Context.getInstance().getDataCheckConsumerAutoOffsetReset());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        props.put("security.protocol", Context.getInstance().getKafkaSecurityProtocol());
        props.put("ssl.truststore.location", Context.getInstance().getSslTrustStoreLocation());
        props.put("sasl.mechanism", Context.getInstance().getKafkaSaslMechanism());
        props.put("ssl.truststore.password", Context.getInstance().getSslTruststorePassword());

        Optional<String> saslJaasConfig = KafkaCredentials.buildSaslJaasConfig(Context.getInstance().getDataCheckConsumerSaslJaasUsername(), Context.getInstance().getDataCheckConsumerSaslJaasPassword());
        saslJaasConfig.ifPresent(s -> props.put("sasl.jaas.config", s));

        this.consumer = new KafkaConsumer<>(props);

        consumer.subscribe(List.of(Context.getInstance().getDataCheckConsumerTopicId()));

        logger.info(consumerName + " initialized.");
    }

    /**
     * Run consumer
     */
    public int run() throws Exception {
        logger.info(consumerName + " is running.");

        DataCheckStrategy dataCheckStrategy = DataCheckStrategyFactory.getStrategy(Context.getInstance().getMicroserviceStrategy());
        return dataCheckStrategy.process(consumer);
    }


    /**
     * Close resources
     * @throws Exception can't close resources
     */
    @Override
    public void close() throws Exception {
        logger.info(consumerName + " closing.");
        consumer.unsubscribe();
        consumer.close();
    }


}
