package com.gozen.kafka.consumer.business.strategy.realtime;

import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategy;
import com.gozen.kafka.consumer.check.DataCheckConsumer;
import com.gozen.ssh.client.ExecClient;
import com.gozen.ssh.client.SftpClient;
import com.jcraft.jsch.JSchException;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * Business consumer with a realtime strategy and check over data
 *
 * Realtime strategy write file in realtime when data is coming from kafka topic, a new file is generated
 * every amount of time configured, before file remplacement, a data check is process
 *
 * Checking data if made by comparing number of lines in file generated into SFTP server and
 * lines expected given by a Kafka topic, the number of lines expected is sum of all synchronization made since last check
 *
 * if the file created into server is correct, old file is delete and new file is can be generated
 * otherwise an error is logged and a new synchronization is needed
 */
public class CheckedRealtimeStrategy implements ConsumerStrategy {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    // consumer to get the number of lines excepted into the file
    private final DataCheckConsumer dataCheckConsumer;

    // SFTP client to manipulate files into server
    private final SftpClient sftpClient;

    // delay before check and file replacement
    private Instant fileTimeout = Instant.EPOCH;

    // the file name
    private String filename;

    // if file is already checked
    private boolean isChecked = true;


    public CheckedRealtimeStrategy() throws JSchException {
        this.sftpClient = new SftpClient();
        this.dataCheckConsumer = new DataCheckConsumer("data-check-consumer");
    }

    /**
     * Apply a checked realtime strategy on business consumer
     * @param consumer business consumer
     * @param fileFormatter file formatter
     * @throws Exception Error during processing
     */
    @Override
    public void process(KafkaConsumer<String, String> consumer, FileFormatter fileFormatter) throws Exception {
        logger.debug("Processing realtime strategy with check ..");

        while(true) {

            logger.debug("Polling ..");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getBusinessConsumerPollTimeoutMs()));

            // if poll is empty, disconnect the session
            if(records.isEmpty()) {
                logger.debug("Empty poll ..");
                sftpClient.close();

                //check file timeout
                if(Instant.now().isAfter(fileTimeout) && !isChecked){
                    isChecked = true;
                    sftpClient.writeDataInFile(getFilePath(), fileFormatter.getFooter());
                    checkFileIntegrity(getAddedLines(fileFormatter));
                }
                continue;
            }

            // setup records to convert into good file format
            fileFormatter.setRecords(records);

            // delete files if time is out
            if(Instant.now().isAfter(fileTimeout)){

                // the new file isn't checked
                isChecked = false;

                logger.debug("Delete existing files in temporary folder ..");
                sftpClient.deleteFilesFolder(Paths.get(Context.getInstance().getSftpPath()));
                filename = generateFilename();

                // build Header
                sftpClient.writeDataInFile(getFilePath(), fileFormatter.getHeader());
                // refresh file timeout
                fileTimeout = Instant.now().plus(Context.getInstance().getDelayBeforeFileReplacementForRealtimeMode(), ChronoUnit.MINUTES);
            }

            // process poll
            for (String record : fileFormatter.getOutputRecords()) {

                sftpClient.writeDataInFile(getFilePath(), record);

                logger.debug("Message appended: "+record);
            }

            logger.debug("Committing offset..");
            consumer.commitSync();

        }
    }

    /**
     * Check data integrity by comparing number of lines of generated file and value expected get from topic
     * @param addedLines number of lines to subtract to total lines of file ( such as header or footer )
     * @throws Exception Error during checking data integrity
     */
    private void checkFileIntegrity(int addedLines) throws Exception {
        logger.info("Checking integrity of data..");
        int linesNumberFromFile;
        int linesNumberFromKafka;

        try(ExecClient execClient = new ExecClient()){
            linesNumberFromFile = execClient.getLinesNumber(getFilePath()) - addedLines;
            linesNumberFromKafka = dataCheckConsumer.run();
        }catch (Exception e){
            logger.error("Something is wrong !");
            logger.error("Integrity of data can't be checked !");
            throw e;
        }

        if(linesNumberFromKafka == linesNumberFromFile){
            logger.info("Generated file have "+linesNumberFromFile+ " lines as expected");
        }else{
            // ko -> log error
            logger.error("Integrity of data is compromise !");
            logger.error("Number of lines in file expected is : "+linesNumberFromKafka);
            logger.error("Number of lines in file generated is : "+linesNumberFromFile);
            logger.error("Generated file path : "+ getFilePath());
            logger.error("New synchronization is needed !");
        }
    }

    /**
     * Count the number of lines added such as header or footer lines
     * @param fileFormatter a configured file formatter
     * @return number of lines added
     */
    private int getAddedLines(FileFormatter fileFormatter) {
        int addedLines = 0;
        if(fileFormatter.withHeader()) addedLines++;
        if(fileFormatter.withFooter()) addedLines++;
        return addedLines;
    }

    /**
     * Build path of file for the definitive folder
     * @return path of file
     */
    private Path getFilePath(){
        return Paths.get(Context.getInstance().getSftpPath(), getFilename());
    }

    /**
     * Get the file name
     * @return file name
     */
    private String getFilename(){
        if(filename==null) filename = generateFilename();
        return filename;
    }

    /**
     * Generate a new file name according the configuration
     * @return file name
     */
    private String generateFilename(){
        if(Context.getInstance().isFileTimestamp()) {
            return Context.getInstance().getFilePrefix() + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Context.getInstance().getFileTimestampPattern())) + "." +Context.getInstance().getFileOutputFormat();
        }else{
            return Context.getInstance().getFilePrefix() + "." + Context.getInstance().getFileOutputFormat();
        }
    }

    /**
     * Close all resources
     * @throws Exception can't close resources
     */
    @Override
    public void close() throws Exception {
        sftpClient.close();
        dataCheckConsumer.close();
    }
}
