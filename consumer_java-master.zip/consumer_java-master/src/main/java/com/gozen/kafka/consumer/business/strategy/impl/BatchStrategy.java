package com.gozen.kafka.consumer.business.strategy.impl;

import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import com.gozen.kafka.consumer.business.strategy.ConsumerStrategy;
import com.gozen.kafka.consumer.check.CheckLinesConsumer;
import com.gozen.ssh.client.ExecClient;
import com.gozen.ssh.client.SftpClient;
import com.jcraft.jsch.JSchException;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class BatchStrategy implements ConsumerStrategy {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final CheckLinesConsumer checkLinesConsumer;
    private final SftpClient sftpClient;

    private Instant fileTimeout = Instant.EPOCH;

    private String filename;

    private boolean isChecked = true;


    public BatchStrategy() throws JSchException {
        this.sftpClient = new SftpClient();
        this.checkLinesConsumer = new CheckLinesConsumer("check-lines-consumer");
    }

    @Override
    public void process(KafkaConsumer<String, String> consumer, FileFormatter fileFormatter) throws Exception {
        logger.debug("Processing batch strategy ..");

        for (int i = 0; i < 10; i++) {

            logger.debug("Polling ..");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getBusinessConsumerPollTimeoutMs()));

            // if poll is empty, disconnect the session
            if(records.isEmpty()) {
                logger.debug("Empty poll ..");
                sftpClient.close();

                //check file timeout
                if(Instant.now().isAfter(fileTimeout) && !isChecked){
                    isChecked = true;
                    sftpClient.writeDataInFile(getFilePathTmp(), fileFormatter.getFooter());
                    if(Context.getInstance().isCheckDataForBatchMode()){
                        checkFileIntegrity(getAddedLines(fileFormatter));
                    }
                }

                continue;
            }

            // setup records to convert into good file format
            fileFormatter.setRecords(records);

            // delete files if time is out
            if(Instant.now().isAfter(fileTimeout)){

                // the new file isn't checked
                isChecked = false;

                logger.debug("Delete existing files in tmp folder ..");
                sftpClient.deleteFilesFolder(getFilePathTmp());
                filename = generateFilename();

                // build Header
                sftpClient.writeDataInFile(getFilePathTmp(), fileFormatter.getHeader());

                // refresh file timeout
                fileTimeout = Instant.now().plus(Context.getInstance().getDelayBeforeFileReplacementForRealtimeMode(), ChronoUnit.MINUTES);
            }

            // process poll
            for (String record : fileFormatter.getOutputRecords()) {

                sftpClient.writeDataInFile(getFilePathTmp(), record);

                logger.debug("Message appended: "+record);
            }

            logger.debug("Committing offset..");
            consumer.commitSync();

        }
    }

    private void checkFileIntegrity(int addedLines) throws Exception {
        logger.info("Checking integrity of data..");
        int linesNumberFromFile = 0;

        try(ExecClient execClient = new ExecClient()){
            linesNumberFromFile = execClient.getLinesNumber(getFilePathTmp());
        }

        int linesNumberFromKafka = checkLinesConsumer.run();

        if(linesNumberFromKafka == (linesNumberFromFile - addedLines)){

            logger.debug("Delete existing files in target folder ..");
            sftpClient.deleteFilesFolder(getFilePath());

            // if ok -> cp file from tmp to final repository
            try(ExecClient execClient = new ExecClient()){
                execClient.moveFile(getFilePathTmp(), getFilePath());
            }
            logger.info("New file is generated with success");

        }else{
            // if ko -> log error
            logger.error("Integrity of data is compromise !");
            logger.error("Number of lines in file expected is : "+linesNumberFromKafka);
            logger.error("Number of lines in file generated is : "+linesNumberFromFile);
            logger.error("Generated file path : "+ getFilePathTmp());
            logger.error("New synchronization is needed !");
        }
    }

    /**
     * Count the number of lines added such as header or footer lines
     * @param fileFormatter a configured file formatter
     * @return number of lines added
     */
    private int getAddedLines(FileFormatter fileFormatter) {
        int addedLines = 0;
        if(fileFormatter.withHeader()) addedLines++;
        if(fileFormatter.withFooter()) addedLines++;
        return addedLines;
    }

    private Path getFilePathTmp(){
        return Paths.get(Context.getInstance().getSftpPathTmp(), getFilename());
    }

    private Path getFilePath(){
        return Paths.get(Context.getInstance().getSftpPath(), getFilename());
    }

    private String getFilename(){
        if(filename==null) filename = generateFilename();
        return filename;
    }

    private String generateFilename(){
        if(Context.getInstance().isFileTimestamp()) {
            return buildTimestampedFileName();
        }else{
            return buildFileName();
        }
    }

    private String buildFileName(){
        return Context.getInstance().getFilePrefix() + "." + Context.getInstance().getFileOutputFormat();
    }

    private String buildTimestampedFileName(){
        return Context.getInstance().getFilePrefix() + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern(Context.getInstance().getFileTimestampPattern())) + "." +Context.getInstance().getFileOutputFormat();

    }

    @Override
    public void close() throws Exception {
        sftpClient.close();
    }
}
