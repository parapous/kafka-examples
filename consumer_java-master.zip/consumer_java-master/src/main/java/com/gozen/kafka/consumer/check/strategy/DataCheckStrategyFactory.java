package com.gozen.kafka.consumer.check.strategy;

import com.gozen.context.Constant;
import com.gozen.kafka.consumer.check.strategy.impl.DataCheckBatchStrategy;
import com.gozen.kafka.consumer.check.strategy.impl.DataCheckRealtimeStrategy;

/**
 * Factory for data check consumer strategy
 */
public class DataCheckStrategyFactory {

    /**
     * Get strategy
     * @param strategy strategy to create
     * @return strategy algorithm
     * @throws Exception unknown strategy
     */
    public static DataCheckStrategy getStrategy(String strategy) throws Exception {

        switch (strategy){
            case Constant.batchStrategy:    return new DataCheckBatchStrategy();
            case Constant.realtimeStrategy: return new DataCheckRealtimeStrategy();
            default : throw new Exception("Strategy unknown !");
        }
    }

}
