package com.gozen.kafka.consumer.check.strategy;

import com.gozen.kafka.consumer.check.EmptyResultException;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public interface DataCheckStrategy {

    /**
     * Process a strategy of consumption of data from Data sCheck consumer
     * @param consumer Data Check consumer
     * @return expected number of lines
     * @throws EmptyResultException No values into topic
     */
    int process(KafkaConsumer<String, String> consumer) throws EmptyResultException;

}
