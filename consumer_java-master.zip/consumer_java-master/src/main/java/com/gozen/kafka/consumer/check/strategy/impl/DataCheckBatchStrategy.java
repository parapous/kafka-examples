package com.gozen.kafka.consumer.check.strategy.impl;

import com.gozen.context.Context;
import com.gozen.kafka.consumer.check.EmptyResultException;
import com.gozen.kafka.consumer.check.strategy.DataCheckStrategy;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Optional;

/**
 * Check lines for batch strategy
 * return the last value of the topic
 */
public class DataCheckBatchStrategy implements DataCheckStrategy {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Consumption of kafka record
     * @param consumer kafka consumer
     * @return last value of topic
     * @throws EmptyResultException no values available in topic
     */
    @Override
    public int process(KafkaConsumer<String, String> consumer) throws EmptyResultException {
        logger.info("Data check with batch Strategy is running.");

        Optional<Integer> linesNumber = Optional.empty();

        while (true) {
            logger.debug("Polling..");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(Context.getInstance().getDataCheckConsumerPollTimeoutMs()));

            if (records.isEmpty()) {
                logger.debug("Empty poll..");
                if (linesNumber.isEmpty())
                    throw new EmptyResultException("No data in Kafka topic for getting lines number of the current sync");

                return linesNumber.get();
            }

            // have to return the last value of the topic
            for (ConsumerRecord<String, String> record : records) {
                logger.debug("Record value = " + record.value());
                linesNumber = Optional.of(Integer.parseInt(record.value()));
            }

            logger.debug("Committing offset..");
            consumer.commitSync();
        }
    }
}
