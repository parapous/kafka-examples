package com.gozen.kafka.consumer.business.strategy;

import com.gozen.context.Constant;
import com.gozen.context.Context;
import com.gozen.kafka.consumer.business.strategy.batch.CheckedBatchStrategy;
import com.gozen.kafka.consumer.business.strategy.realtime.CheckedRealtimeStrategy;
import com.gozen.kafka.consumer.business.strategy.batch.UncheckedBatchStrategy;
import com.gozen.kafka.consumer.business.strategy.realtime.UncheckedRealtimeStrategy;
import com.jcraft.jsch.JSchException;

/**
 * Factory for business consumer strategy
 */
public class ConsumerStrategyFactory {

    /**
     * Get a strategy
     * @param strategy strategy to create
     * @return strategy algorithm
     * @throws Exception unknown strategy
     */
    public static ConsumerStrategy getStrategy(String strategy) throws Exception {

        switch (strategy){
            case Constant.batchStrategy:    return getBatchStrategy();
            case Constant.realtimeStrategy: return getRealtimeStrategy();
            default : throw new Exception("Strategy unknown !");
        }
    }

    /**
     * Group of batch strategy
     * @return checked/Unchecked batch strategy according to configuration
     * @throws JSchException Error during strategy building
     */
    private static ConsumerStrategy getBatchStrategy() throws JSchException {
        if(Context.getInstance().isEnableDataCheck()){
            return new CheckedBatchStrategy();
        }else{
            return new UncheckedBatchStrategy();
        }
    }

    /**
     * Group of realtime strategy
     * @return checked/Unchecked realtime strategy according to configuration
     * @throws JSchException Error during strategy building
     */
    private static ConsumerStrategy getRealtimeStrategy() throws JSchException {
        if(Context.getInstance().isEnableDataCheck()){
            return new CheckedRealtimeStrategy();
        }else{
            return new UncheckedRealtimeStrategy();
        }
    }
}
