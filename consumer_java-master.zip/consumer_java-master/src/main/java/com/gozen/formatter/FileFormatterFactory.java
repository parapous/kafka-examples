package com.gozen.formatter;

import com.gozen.context.Constant;
import com.gozen.formatter.format.CsvFile;
import com.gozen.formatter.format.JsonFile;

/**
 * File formatter factory
 */
public class FileFormatterFactory {

    public static FileFormatter getFileConverter(String fileFormat) throws Exception {

        switch (fileFormat){
            case Constant.CSV : return new CsvFile();
            case Constant.JSON: return new JsonFile();
            default : throw new Exception("Output file format unknown !");
        }
    }
}
