package com.gozen.formatter.format;

import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * File formatter for JSON
 */
public class JsonFile implements FileFormatter {

    // List of records to format
    private List<String> records;

    /**
     * Convert ConsumerRecord into List of String
     * @param consumerRecords records to format
     */
    @Override
    public void setRecords(ConsumerRecords<String, String> consumerRecords) {
        this.records = new ArrayList<>();
        consumerRecords.forEach(r -> records.add(r.value()));
    }

    /**
     * Get records converted into JSON format
     * @return list of converted record (JSON object)
     */
    @Override
    public List<String> getOutputRecords() {
        return records.stream().map(this::convertRecord).collect(Collectors.toList());
    }

    /**
     * Convert the given String into JSON object
     * @param record Json String to convert
     * @return JSON line
     */
    private String convertRecord(String record) {
        return record + lineSeparator;
    }

    /**
     * Header of file
     * @return the header
     */
    @Override
    public String getHeader() {
        return Context.getInstance().getJsonHeader() + lineSeparator;
    }

    /**
     * Footer of file
     * @return the footer
     */
    @Override
    public String getFooter() {
        return Context.getInstance().getJsonFooter() + lineSeparator;
    }

    /**
     * Describe if the file have header
     * @return true if file have header, false otherwise
     */
    @Override
    public boolean withHeader() {
        return Context.getInstance().getJsonHeader() != null;
    }

    /**
     * Describe if the file have footer
     * @return true if file have footer, false otherwise
     */
    @Override
    public boolean withFooter() {
        return Context.getInstance().getJsonFooter() != null;
    }
}
