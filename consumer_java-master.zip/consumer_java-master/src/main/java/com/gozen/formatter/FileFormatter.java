package com.gozen.formatter;

import com.gozen.context.Context;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import java.util.List;

/**
 * Contract for file formatters
 */
public interface FileFormatter {

    // Configured line separator
    String lineSeparator = Context.getInstance().getFileRecordSeparator();

    void setRecords(ConsumerRecords<String, String> records);

    List<String> getOutputRecords() throws Exception;

    default String getHeader() throws Exception {
        return null;
    }

    default String getFooter() throws Exception {
        return null;
    }

    boolean withHeader();

    boolean withFooter();
}
