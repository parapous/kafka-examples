package com.gozen.formatter.format;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.gozen.context.Constant;
import com.gozen.context.Context;
import com.gozen.formatter.FileFormatter;
import org.apache.kafka.clients.consumer.ConsumerRecords;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * File formatter for CSV
 */
public class CsvFile implements FileFormatter {


    // List of records to format
    private List<String> records;

    // List of CSV column name
    private List<String> header;

    /**
     * Convert ConsumerRecord into List of String
     * @param consumerRecords records to format
     */
    @Override
    public void setRecords(ConsumerRecords<String, String> consumerRecords) {
        this.records = new ArrayList<>();
        consumerRecords.forEach(r -> records.add(r.value()));
    }

    /**
     * Header of file
     * @return the header
     * @throws Exception can't create header
     */
    @Override
    public String getHeader() throws Exception {
        buildHeader();
        return String.join(Context.getInstance().getCsvDataDelimiter(), header) + lineSeparator;
    }

    /**
     * Describe if the file have header
     * @return true if file have header, false otherwise
     */
    @Override
    public boolean withHeader() {
        return true;
    }

    /**
     * Describe if the file have footer
     * @return true if file have footer, false otherwise
     */
    @Override
    public boolean withFooter() {
        return false;
    }

    /**
     * Get records converted into CSV format
     * @return list of converted record (CSV raw)
     * @throws IllegalStateException No header in file
     */
    @Override
    public List<String> getOutputRecords() throws IllegalStateException {
        if(header==null) throw new IllegalStateException("Can't prepare data without CSV header");
        return records.stream().map(this::convertRecord).collect(Collectors.toList());
    }

    /**
     * Build the header of file
     * @throws Exception Can't create header
     */
    private void buildHeader() throws Exception {
        if(records==null) throw new IllegalStateException("Need to set records");

        Optional<String> record = records.stream().findFirst();
        if(record.isPresent()){

            JsonObject json = JsonParser.parseString(record.get()).getAsJsonObject();
            header = json.entrySet().stream().map(Map.Entry::getKey).collect(Collectors.toList());

        }else {
            throw new Exception("Can't build CSV header");
        }
    }

    /**
     * Convert the given String into CSV raw
     * @param record Json String to convert
     * @return CSV raw line
     */
    private String convertRecord(String record) {
        JsonObject json = JsonParser.parseString(record).getAsJsonObject();
        return header.stream().map(h -> setupQuote(json.get(h).getAsString())).collect(Collectors.joining(Context.getInstance().getCsvDataDelimiter())) + lineSeparator;
    }

    /**
     * According to RFC 4180, wrapping data into double-quote and
     * convert double-quote present in data into double double-quote
     * @param data data to quote
     * @return data quoted
     */
    private String setupQuote(String data){
        if(Context.getInstance().isCsvWithDataQuote()){
            return "\""+data.replaceAll("\"","\"\"")+"\"";
        }else {
            return data;
        }
    }



}
